"""Check the latest version at https://pypi.org/project/slack-bolt/"""

__version__ = "1.27.0"
