ENCODING = "utf-8"  # The content encoding for Slack requests/responses is always utf-8
